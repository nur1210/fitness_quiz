﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyProject
{
    public static class Database
    {
        public static List<TrainigProgram> Programs = new List<TrainigProgram>();
        public static List<Question> Questions = new List<Question>();
    }
}
