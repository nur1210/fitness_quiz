﻿namespace MyProject
{
    partial class EditProgram
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEdit = new System.Windows.Forms.Button();
            this.lblInfo = new System.Windows.Forms.Label();
            this.lbxPrograms = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(701, 406);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(2);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(108, 53);
            this.btnEdit.TabIndex = 5;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Location = new System.Drawing.Point(402, 77);
            this.lblInfo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(35, 20);
            this.lblInfo.TabIndex = 4;
            this.lblInfo.Text = "Info";
            // 
            // lbxPrograms
            // 
            this.lbxPrograms.FormattingEnabled = true;
            this.lbxPrograms.ItemHeight = 20;
            this.lbxPrograms.Location = new System.Drawing.Point(52, 77);
            this.lbxPrograms.Margin = new System.Windows.Forms.Padding(2);
            this.lbxPrograms.Name = "lbxPrograms";
            this.lbxPrograms.Size = new System.Drawing.Size(305, 404);
            this.lbxPrograms.TabIndex = 3;
            this.lbxPrograms.SelectedIndexChanged += new System.EventHandler(this.lbxPrograms_SelectedIndexChanged);
            // 
            // EditProgram
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(862, 515);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.lbxPrograms);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "EditProgram";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EditProgram";
            this.Load += new System.EventHandler(this.EditProgram_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnEdit;
        private Label lblInfo;
        private ListBox lbxPrograms;
    }
}